package de.primevoice.common;

import java.util.ArrayList;
import java.util.List;

/** Einfache zuverlässige Dateiübertragung über UDP (Fenster + Wiederholung). */
public final class Transfer {
    public static final int CHUNK = 900, WINDOW = 12, RETRY_MS = 400;
    private Transfer() {}

    public static final class Sender {
        public final int id;
        private final byte[] data;
        private final int n;
        private final long[] sent;
        private final boolean[] acked;
        private int first = 0;

        public Sender(int id, byte[] data) {
            this.id = id; this.data = data;
            this.n = Math.max(1, (data.length + CHUNK - 1) / CHUNK);
            this.sent = new long[n]; this.acked = new boolean[n];
        }
        public int total() { return data.length; }
        public synchronized List<Integer> due(long now) {
            List<Integer> out = new ArrayList<>();
            while (first < n && acked[first]) first++;
            for (int i = first; i < n && i < first + WINDOW; i++)
                if (!acked[i] && (sent[i] == 0 || now - sent[i] > RETRY_MS)) { sent[i] = now; out.add(i); }
            return out;
        }
        public byte[] chunk(int idx) {
            int off = idx * CHUNK, len = Math.min(CHUNK, data.length - off);
            return new Msg(Msg.FILE_CHUNK).i(id).i(idx).s(Math.max(0, len)).bytes(data, off, Math.max(0, len)).done();
        }
        public synchronized void ack(int idx) { if (idx >= 0 && idx < n) acked[idx] = true; }
        public synchronized boolean done() { for (boolean a : acked) if (!a) return false; return true; }
    }

    public static final class Receiver {
        public final int id, kind;
        public final float gain;
        public final String name;
        private final byte[] buf;
        private final boolean[] got;

        public Receiver(int id, int kind, float gain, String name, int total) {
            this.id = id; this.kind = kind; this.gain = gain; this.name = name;
            this.buf = new byte[total];
            this.got = new boolean[Math.max(1, (total + CHUNK - 1) / CHUNK)];
        }
        public synchronized void put(int idx, byte[] d) {
            if (idx < 0 || idx >= got.length) return;
            int off = idx * CHUNK;
            if (off + d.length > buf.length) return;
            System.arraycopy(d, 0, buf, off, d.length);
            got[idx] = true;
        }
        public synchronized boolean done() { for (boolean g : got) if (!g) return false; return true; }
        public byte[] data() { return buf; }
    }
}
