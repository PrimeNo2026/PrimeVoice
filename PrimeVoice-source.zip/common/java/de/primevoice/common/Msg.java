package de.primevoice.common;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** Kleiner Schreiber/Leser für Steuer- und Audiopakete. */
public final class Msg {
    // Client -> Server
    public static final int C_STATE = 1, C_VOLUMES = 2, FILE_BEGIN = 10, FILE_CHUNK = 11, FILE_ACK = 12;
    // Server -> Client
    public static final int S_SET_VOLUME = 20, S_MIC = 21, S_PICK_FILE = 22, S_PLAY = 23;
    // Dateitypen
    public static final int KIND_UPLOAD = 0, KIND_OGG = 1, KIND_PCM = 2;

    private final ByteArrayOutputStream bo = new ByteArrayOutputStream();

    public Msg(int type) { b(type); }
    public Msg b(int v) { bo.write(v); return this; }
    public Msg s(int v) { bo.write(v >>> 8); bo.write(v); return this; }
    public Msg i(int v) { s(v >>> 16); s(v); return this; }
    public Msg f(float v) { return i(Float.floatToIntBits(v)); }
    public Msg uuid(UUID u) {
        ByteBuffer bb = ByteBuffer.allocate(16).putLong(u.getMostSignificantBits()).putLong(u.getLeastSignificantBits());
        bo.writeBytes(bb.array());
        return this;
    }
    public Msg str(String x) { byte[] d = x.getBytes(StandardCharsets.UTF_8); s(d.length); bo.writeBytes(d); return this; }
    public Msg bytes(byte[] d, int off, int len) { bo.write(d, off, len); return this; }
    public byte[] done() { return bo.toByteArray(); }

    public static final class In {
        private final ByteBuffer bb;
        public In(byte[] d) { bb = ByteBuffer.wrap(d); }
        public int b() { return bb.get() & 0xFF; }
        public int s() { return bb.getShort() & 0xFFFF; }
        public int i() { return bb.getInt(); }
        public float f() { return bb.getFloat(); }
        public UUID uuid() { return new UUID(bb.getLong(), bb.getLong()); }
        public String str() { byte[] d = new byte[s()]; bb.get(d); return new String(d, StandardCharsets.UTF_8); }
        public byte[] bytes(int n) { byte[] d = new byte[n]; bb.get(d); return d; }
        public int remaining() { return bb.remaining(); }
    }
}
