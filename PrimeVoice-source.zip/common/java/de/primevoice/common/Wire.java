package de.primevoice.common;

import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** UDP-Paketformat: type(1) sessionId(8) counter(8) AES-128-GCM(payload). Header ist AAD. */
public final class Wire {
    public static final int T_HELLO = 1, T_AUDIO_UP = 2, T_AUDIO_DOWN = 3, T_CTRL = 4;
    public static final int DIR_C2S = 0, DIR_S2C = 1;
    public static final int RATE = 48000, FRAME = 960, HEADER = 17, TAG = 16;
    public static final String LINK_PREFIX = "[PV1]";

    private Wire() {}

    private static byte[] nonce(int dir, long ctr) {
        ByteBuffer b = ByteBuffer.allocate(12);
        b.put((byte) dir).put((byte) 0).put((byte) 0).put((byte) 0).putLong(ctr);
        return b.array();
    }

    public static byte[] seal(int type, long session, long counter, int dir, byte[] key, byte[] plain)
            throws GeneralSecurityException {
        ByteBuffer hdr = ByteBuffer.allocate(HEADER);
        hdr.put((byte) type).putLong(session).putLong(counter);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce(dir, counter)));
        c.updateAAD(hdr.array());
        byte[] ct = c.doFinal(plain);
        byte[] out = new byte[HEADER + ct.length];
        System.arraycopy(hdr.array(), 0, out, 0, HEADER);
        System.arraycopy(ct, 0, out, HEADER, ct.length);
        return out;
    }

    /** Entschlüsselt und prüft die Authentizität. Wirft bei manipulierten Paketen. */
    public static byte[] open(byte[] pkt, int len, int dir, byte[] key) throws GeneralSecurityException {
        long counter = counter(pkt);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce(dir, counter)));
        c.updateAAD(pkt, 0, HEADER);
        return c.doFinal(pkt, HEADER, len - HEADER);
    }

    public static boolean plausible(int len) { return len >= HEADER + TAG && len <= 1400; }
    public static int type(byte[] p) { return p[0] & 0xFF; }
    public static long session(byte[] p) { return ByteBuffer.wrap(p, 1, 8).getLong(); }
    public static long counter(byte[] p) { return ByteBuffer.wrap(p, 9, 8).getLong(); }

    public static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }
    public static byte[] unhex(String s) {
        byte[] b = new byte[s.length() / 2];
        for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        return b;
    }
}
