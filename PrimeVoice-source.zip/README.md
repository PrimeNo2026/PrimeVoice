# PrimeVoice

Eigenstaendiger Minecraft-Voicechat (ohne Simple Voice Chat / Plasmo Voice):

* **PrimeVoice-Paper-26.3.jar** – Paper-Plugin (Server)
* **PrimeVoice-Forge-26.3.jar** – Client-Mod fuer Forge
* **PrimeVoice-Fabric-26.3.jar** – Client-Mod fuer Fabric (braucht die Fabric API)

Forge- und Fabric-Spieler hoeren sich gegenseitig, da das Audio ueber das Paper-Plugin laeuft.

Alle drei Dateien werden bei jedem GitHub-Release automatisch durch GitHub Actions gebaut und einzeln angehaengt.

## Funktionen
* Proximity-Chat mit Entfernungsleiser, Waenden (Raycast, bis 3 Waende, gedaempft per Tiefpass + Pegel), Welten getrennt, Stereo-Positionierung
* Gruppen (oeffentlich / passwortgeschuetzt), klickbare Liste, Gruppenmitglieder hoeren sich ueberall
* `/vc on|off`, `/group create|join|leave`, `/volume` (lokal gespeichert), `/soundboard` (Admin, Permission `primevoice.soundboard`)
* Opus (24 kbit/s, 20 ms), AES-128-GCM, Replay-Schutz, keine Aufzeichnung
* Spieler ohne Mikrofon hoeren trotzdem alles; Mikrofon wird alle 3 s automatisch neu gesucht; keine Fehlermeldungen
* Funktioniert mit **einem** UDP-Port (exaroton): Voice nutzt UDP auf derselben Portnummer wie der Minecraft-Server (TCP)

## Technik in Kuerze
Die Mod faengt beim Beitritt eine unsichtbare Chatnachricht `[PV1]host|port|sessionId|key` des Plugins ab (die Verbindung ist durch Mojang-Login verschluesselt). Danach laeuft alles ueber UDP. Das Plugin sendet diese Nachricht nur an Clients mit Forge-Brand; `/vc link` erzeugt sie neu.
Spieler ohne Mod koennen normal beitreten, nehmen aber nicht am Voicechat teil.

## Bekannte Grenzen
* Die Oberflaeche ist die Actionbar (Mikro-Status, stumm, Gruppe, wie viele dich hoeren) plus Inventar-Menues auf dem Server. Eine eigene Minecraft-GUI (Screens) enthaelt die Mod nicht.
* Die 20 Standard-Sounds sind selbst synthetisierte Effekte (keine Fremd-Samples). Eigene Sounds: OGG/Vorbis.
* Der Datei-Dialog fuer den Upload nutzt AWT und ist auf Windows/Linux gedacht (macOS: unzuverlaessig).
* Die Loader-Anbindungen (`PrimeVoiceMod.java` fuer Forge, `PrimeVoiceFabric.java` fuer Fabric, je ~15 Zeilen) sind nicht gegen die echten 26.3-APIs getestet.
