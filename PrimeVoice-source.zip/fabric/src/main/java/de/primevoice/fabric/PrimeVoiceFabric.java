package de.primevoice.fabric;

import de.primevoice.client.LinkHandler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;

/** Fabric-Glue: faengt die Link-Nachricht des Servers ab. Der Rest ist reines Java (client-core). */
public final class PrimeVoiceFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // ALLOW_GAME: true = Nachricht anzeigen, false = verwerfen
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> !LinkHandler.accept(message.getString()));
    }
}
