package de.primevoice.paper;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/** 20 synthetische Spasssounds (PCM, selbst erzeugt, keine Urheberrechte) + hochgeladene OGG-Dateien. */
final class Sounds {
    static final int PCM_RATE = 22050;
    private final Path dir;
    private final Map<String, byte[]> builtin = new LinkedHashMap<>();

    Sounds(Path dataFolder) throws IOException {
        this.dir = dataFolder.resolve("sounds");
        Files.createDirectories(dir);
        buildBuiltins();
    }

    List<String> builtinNames() { return new ArrayList<>(builtin.keySet()); }
    byte[] builtin(String n) { return builtin.get(n); }

    List<String> customNames() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir)) {
            s.filter(p -> p.getFileName().toString().endsWith(".ogg")).sorted().forEach(p -> {
                String f = p.getFileName().toString();
                out.add(f.substring(0, f.length() - 4));
            });
        } catch (IOException ignored) {}
        return out;
    }

    static String safeName(String raw) {
        String n = raw.replaceAll("(?i)\\.ogg$", "").replaceAll("[^A-Za-z0-9_\\- ]", "").trim();
        if (n.length() > 24) n = n.substring(0, 24);
        return n;
    }

    byte[] custom(String n) throws IOException {
        Path p = dir.resolve(safeName(n) + ".ogg");
        return Files.isRegularFile(p) ? Files.readAllBytes(p) : null;
    }
    boolean deleteCustom(String n) throws IOException { return Files.deleteIfExists(dir.resolve(safeName(n) + ".ogg")); }
    boolean exists(String n) { return builtin.containsKey(n) || Files.exists(dir.resolve(safeName(n) + ".ogg")); }
    void saveCustom(String n, byte[] d) throws IOException { Files.write(dir.resolve(safeName(n) + ".ogg"), d); }

    /** Prueft OGG/Vorbis-Struktur und liefert die Dauer in Sekunden (oder -1 bei ungueltigen Daten). */
    static double oggSeconds(byte[] d) {
        try {
            if (d.length < 64 || !"OggS".equals(new String(d, 0, 4, StandardCharsets.ISO_8859_1))) return -1;
            ByteBuffer b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN);
            int segs = d[26] & 0xFF;
            int off = 27 + segs;
            if (d[off] != 1 || !"vorbis".equals(new String(d, off + 1, 6, StandardCharsets.ISO_8859_1))) return -1;
            int rate = b.getInt(off + 12);
            if (rate < 8000 || rate > 192000) return -1;
            long last = -1;
            for (int i = d.length - 14; i >= 0; i--) {
                if (d[i] == 'O' && d[i + 1] == 'g' && d[i + 2] == 'g' && d[i + 3] == 'S') { last = b.getLong(i + 6); break; }
            }
            return last <= 0 ? -1 : (double) last / rate;
        } catch (RuntimeException e) { return -1; }
    }

    private interface Gen { double at(double t); }

    private void add(String name, double secs, Gen g) {
        int n = (int) (secs * PCM_RATE);
        ByteBuffer b = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < n; i++) {
            double t = (double) i / PCM_RATE;
            double env = Math.min(1, t * 80) * Math.min(1, (secs - t) * 40);
            double v = Math.max(-1, Math.min(1, g.at(t) * env)) * 0.8;
            b.putShort((short) (v * 32767));
        }
        builtin.put(name, b.array());
    }
    private static double sq(double p) { return Math.sin(p) >= 0 ? 1 : -1; }
    private static final java.util.Random R = new java.util.Random(42);

    private void buildBuiltins() {
        double P = 2 * Math.PI;
        add("Boing", 0.6, t -> Math.sin(P * (200 + 300 * Math.abs(Math.sin(t * 9)) * Math.exp(-t * 3)) * t) * Math.exp(-t * 3));
        add("Laser", 0.4, t -> sq(P * (1800 - 3500 * t) * t) * 0.5);
        add("Sirene", 1.5, t -> Math.sin(P * (700 + 300 * Math.sin(P * 1.2 * t)) * t));
        add("Pups", 0.5, t -> Math.sin(P * (90 - 60 * t) * t) * Math.exp(-t * 4) + (R.nextDouble() - .5) * 0.3 * Math.exp(-t * 8));
        add("Quak", 0.45, t -> sq(P * (350 - 150 * t) * t) * 0.6 * (0.6 + 0.4 * Math.sin(P * 40 * t)));
        add("Alarm", 1.2, t -> sq(P * ((int) (t * 6) % 2 == 0 ? 900 : 600) * t) * 0.5);
        add("Sad Trombone", 1.6, t -> sq(P * (t < .4 ? 233 : t < .8 ? 220 : t < 1.2 ? 208 : 196 - 20 * (t - 1.2)) * t) * 0.5);
        add("Level Up", 0.8, t -> Math.sin(P * (t < .2 ? 523 : t < .4 ? 659 : t < .6 ? 784 : 1047) * t) * 0.8);
        add("Fehler", 0.5, t -> sq(P * 150 * t) * ((int) (t * 12) % 2 == 0 ? 1 : 0.2));
        add("Ufo", 1.2, t -> Math.sin(P * (400 + 250 * Math.sin(P * 5 * t)) * t));
        add("Rülpser", 0.7, t -> sq(P * (70 + 20 * Math.sin(P * 9 * t)) * t) * 0.7 * Math.exp(-t * 2));
        add("Kuckuck", 0.7, t -> Math.sin(P * (t < .3 ? 780 : t > .4 && t < .7 ? 620 : 0) * t));
        add("Explosion", 1.0, t -> (R.nextDouble() * 2 - 1) * Math.exp(-t * 4));
        add("Plopp", 0.2, t -> Math.sin(P * (900 - 3000 * t) * t) * Math.exp(-t * 15));
        add("Münze", 0.5, t -> Math.sin(P * (t < .08 ? 988 : 1319) * t) * Math.exp(-t * 6));
        add("Roboter", 0.8, t -> sq(P * 120 * t) * Math.sin(P * 30 * t) * 0.8);
        add("Glückwunsch", 1.0, t -> (Math.sin(P * 523 * t) + Math.sin(P * 659 * t) + Math.sin(P * 784 * t)) / 3 * Math.exp(-t * 2));
        add("Tröte", 0.7, t -> sq(P * 440 * t) * 0.5 + sq(P * 445 * t) * 0.5);
        add("Gespenst", 1.3, t -> Math.sin(P * (300 + 100 * Math.sin(P * 3 * t)) * t) * (0.5 + 0.5 * Math.sin(P * 6 * t)));
        add("Schlürf", 0.6, t -> Math.sin(P * (300 + 900 * t) * t) * (0.5 + 0.5 * Math.sin(P * 45 * t)));
    }
}
