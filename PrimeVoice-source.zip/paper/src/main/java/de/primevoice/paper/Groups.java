package de.primevoice.paper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Sprachgruppen. Passwoerter werden nur als Salted-Hash im Speicher gehalten. */
final class Groups {
    static final class Group {
        final String name;
        final UUID owner;
        final byte[] salt;
        final byte[] hash; // null = oeffentlich
        final Set<UUID> members = new LinkedHashSet<>();
        Group(String name, UUID owner, byte[] salt, byte[] hash) { this.name = name; this.owner = owner; this.salt = salt; this.hash = hash; }
        boolean isPrivate() { return hash != null; }
    }

    private final Map<String, Group> groups = new ConcurrentHashMap<>();
    private final SecureRandom rnd = new SecureRandom();

    private static byte[] hash(byte[] salt, String pw) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            return md.digest(pw.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    synchronized String create(UUID owner, String name, String password) {
        if (name.length() < 2 || name.length() > 16 || !name.matches("[A-Za-z0-9_\\-]+")) return "Ungueltiger Name (2-16 Zeichen: A-Z, 0-9, _ -).";
        if (groups.containsKey(name.toLowerCase())) return "Diese Gruppe existiert bereits.";
        byte[] salt = new byte[16]; rnd.nextBytes(salt);
        Group g = new Group(name, owner, salt, password == null ? null : hash(salt, password));
        g.members.add(owner);
        groups.put(name.toLowerCase(), g);
        return null;
    }

    synchronized String join(UUID p, String name, String password) {
        Group g = groups.get(name.toLowerCase());
        if (g == null) return "Gruppe nicht gefunden.";
        if (g.isPrivate()) {
            if (password == null || !MessageDigest.isEqual(g.hash, hash(g.salt, password))) return "Falsches Passwort.";
        }
        g.members.add(p);
        return null;
    }

    /** @return Name der verlassenen Gruppe oder null */
    synchronized String leave(UUID p) {
        for (Group g : groups.values()) {
            if (g.members.remove(p)) {
                if (g.members.isEmpty()) groups.remove(g.name.toLowerCase());
                return g.name;
            }
        }
        return null;
    }

    Group find(String name) { return name == null ? null : groups.get(name.toLowerCase()); }
    List<Group> all() { return new ArrayList<>(groups.values()); }
}
