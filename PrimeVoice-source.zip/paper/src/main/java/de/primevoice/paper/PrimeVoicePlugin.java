package de.primevoice.paper;

import de.primevoice.common.Msg;
import de.primevoice.common.Transfer;
import de.primevoice.common.Wire;
import java.net.InetSocketAddress;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class PrimeVoicePlugin extends JavaPlugin implements CommandExecutor, TabCompleter, Listener {
    private VoiceServer voice;
    private Sounds sounds;
    private final Groups groups = new Groups();
    private final SecureRandom rnd = new SecureRandom();
    private final Map<UUID, Long> sbCooldown = new ConcurrentHashMap<>();

    /** Inventar-Halter mit Typ und Daten. */
    private static final class Gui implements InventoryHolder {
        final String type;
        final UUID target;
        final List<?> items;
        Inventory inv;
        Gui(String type, UUID target, List<?> items) { this.type = type; this.target = target; this.items = items; }
        @Override public Inventory getInventory() { return inv; }
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        try {
            sounds = new Sounds(getDataFolder().toPath());
            int port = getConfig().getInt("udp-port", 0);
            if (port <= 0) port = Bukkit.getPort();
            String ip = Bukkit.getIp();
            InetSocketAddress bind = ip == null || ip.isBlank() ? new InetSocketAddress(port) : new InetSocketAddress(ip, port);
            voice = new VoiceServer(bind, getLogger());
            voice.onUpload = this::handleUpload;
            getLogger().info("PrimeVoice-UDP lauscht auf " + bind + " (gleicher Port wie der Minecraft-Server)");
        } catch (Exception e) {
            getLogger().severe("PrimeVoice konnte nicht starten: " + e);
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        for (String c : List.of("vc", "group", "volume", "soundboard")) {
            var cmd = getCommand(c);
            if (cmd != null) { cmd.setExecutor(this); cmd.setTabCompleter(this); }
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::computeAudibility, 20L, 5L);
        Bukkit.getScheduler().runTaskTimer(this, this::actionBar, 40L, 20L);
    }

    @Override
    public void onDisable() { if (voice != null) voice.close(); }

    // ---------------------------------------------------------------- Link / Session

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) return;
            String brand = p.getClientBrandName();
            if (brand != null && (brand.toLowerCase(Locale.ROOT).contains("forge") || brand.toLowerCase(Locale.ROOT).contains("fabric"))) link(p);
        }, 60L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID u = e.getPlayer().getUniqueId();
        groups.leave(u);
        Session s = voice.byPlayer.remove(u);
        if (s != null) voice.bySession.remove(s.id);
        sbCooldown.remove(u);
    }

    private void link(Player p) {
        Session old = voice.byPlayer.remove(p.getUniqueId());
        if (old != null) voice.bySession.remove(old.id);
        String host = getConfig().getString("public-host", "");
        InetSocketAddress vh = p.getVirtualHost();
        if (host.isBlank() && vh != null) host = vh.getHostString();
        int port = getConfig().getInt("public-port", 0);
        if (port <= 0) port = getConfig().getInt("udp-port", 0);
        if (port <= 0) port = vh != null ? vh.getPort() : Bukkit.getPort();
        if (host.isBlank()) { p.sendMessage(Component.text("PrimeVoice: Serveradresse unbekannt (public-host setzen).", NamedTextColor.RED)); return; }
        long id = rnd.nextLong() & Long.MAX_VALUE;
        byte[] key = new byte[16];
        rnd.nextBytes(key);
        Session s = new Session(p.getUniqueId(), p.getName(), id, key);
        voice.bySession.put(id, s);
        voice.byPlayer.put(p.getUniqueId(), s);
        // Wird von der Forge-Mod abgefangen und nicht angezeigt.
        p.sendMessage(Component.text(Wire.LINK_PREFIX + host + "|" + port + "|" + String.format("%016x", id) + "|" + Wire.hex(key)));
    }

    private Session need(Player p) {
        Session s = voice.byPlayer.get(p.getUniqueId());
        if (s == null || !s.connected()) {
            p.sendMessage(Component.text("PrimeVoice-Mod nicht verbunden. Ist die Forge-Mod installiert? Versuche /vc link.", NamedTextColor.RED));
            return null;
        }
        return s;
    }

    // ---------------------------------------------------------------- Berechnung Hoerbarkeit (Hauptthread)

    private void computeAudibility() {
        double max = getConfig().getDouble("max-distance", 48.0);
        List<Session> list = new ArrayList<>();
        for (Session s : voice.byPlayer.values()) if (s.connected() && Bukkit.getPlayer(s.uuid) != null) list.add(s);
        for (Session sp : list) {
            Player a = Bukkit.getPlayer(sp.uuid);
            if (a == null) continue;
            Map<UUID, float[]> out = new HashMap<>();
            Location la = a.getEyeLocation();
            for (Session rs : list) {
                if (rs == sp) continue;
                Player b = Bukkit.getPlayer(rs.uuid);
                if (b == null) continue;
                float[] v = null;
                if (sp.group != null && sp.group.equalsIgnoreCase(rs.group)) v = new float[] {1f, 0f, 0f};
                Location lb = b.getEyeLocation();
                if (v == null && la.getWorld() == lb.getWorld()) {
                    double d = la.distance(lb);
                    if (d <= max) {
                        int walls = countWalls(la, lb, d);
                        double gain = Math.pow(1.0 - d / max, 1.5) * Math.pow(0.6, walls);
                        v = new float[] {(float) gain, pan(lb, la), Math.min(3, walls)};
                    }
                }
                if (v != null) out.put(rs.uuid, v);
            }
            sp.audible = out;
        }
    }

    private int countWalls(Location a, Location b, double dist) {
        World w = a.getWorld();
        Vector dir = b.toVector().subtract(a.toVector());
        if (dir.lengthSquared() < 1e-6) return 0;
        dir.normalize();
        Location cur = a.clone();
        double travelled = 0;
        int walls = 0;
        while (walls < 3 && travelled < dist) {
            RayTraceResult r = w.rayTraceBlocks(cur, dir, dist - travelled, FluidCollisionMode.NEVER, true);
            if (r == null || r.getHitBlock() == null) break;
            walls++;
            double step = cur.toVector().distance(r.getHitPosition()) + 1.0;
            cur.add(dir.clone().multiply(step));
            travelled += step;
        }
        return walls;
    }

    /** Stereo-Position (-1 links .. +1 rechts) des Sprechers aus Sicht des Hoerers. */
    private float pan(Location listener, Location speaker) {
        double dx = speaker.getX() - listener.getX(), dz = speaker.getZ() - listener.getZ();
        double len = Math.hypot(dx, dz);
        if (len < 0.01) return 0f;
        double yaw = Math.toRadians(listener.getYaw());
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);
        return (float) ((dx * rx + dz * rz) / len);
    }

    private void actionBar() {
        for (Session s : voice.byPlayer.values()) {
            if (!s.connected()) continue;
            Player p = Bukkit.getPlayer(s.uuid);
            if (p == null) continue;
            boolean talking = System.currentTimeMillis() - s.lastTalk < 600;
            String mic = !s.micOn ? "Mikro: AUS (stumm)" : !s.clientHasMic ? "Kein Mikrofon erkannt (du kannst hoeren)" : talking ? "Du sprichst" : "Mikro: AN";
            String grp = s.group == null ? "keine Gruppe" : "Gruppe: " + s.group;
            String who = talking ? " | Hoeren dich: " + s.listenerCount : "";
            p.sendActionBar(Component.text(mic + " | " + grp + who, !s.micOn ? NamedTextColor.RED : NamedTextColor.GREEN));
        }
    }

    // ---------------------------------------------------------------- Befehle

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] a) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Nur im Spiel nutzbar."); return true; }
        switch (cmd.getName().toLowerCase(Locale.ROOT)) {
            case "vc" -> {
                if (a.length == 1 && a[0].equalsIgnoreCase("link")) { link(p); return true; }
                Session s = need(p);
                if (s == null) return true;
                if (a.length == 1 && a[0].equalsIgnoreCase("on")) { s.micOn = true; }
                else if (a.length == 1 && a[0].equalsIgnoreCase("off")) { s.micOn = false; }
                else { p.sendMessage(Component.text("Nutzung: /vc <on|off>", NamedTextColor.YELLOW)); return true; }
                voice.sendCtrl(s, new Msg(Msg.S_MIC).b(s.micOn ? 1 : 0).done());
                p.sendMessage(Component.text(s.micOn ? "Mikrofon aktiviert." : "Sprachuebertragung aus. Du hoerst weiterhin andere.", NamedTextColor.GREEN));
            }
            case "group" -> group(p, a);
            case "volume" -> { if (need(p) != null) openVolume(p); }
            case "soundboard" -> {
                if (!p.hasPermission("primevoice.soundboard")) { p.sendMessage(Component.text("Keine Berechtigung.", NamedTextColor.RED)); return true; }
                if (need(p) != null) openPlayers(p);
            }
            default -> { return false; }
        }
        return true;
    }

    private void group(Player p, String[] a) {
        Session s = need(p);
        if (s == null) return;
        String sub = a.length == 0 ? "" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create" -> {
                if (a.length == 1) {
                    p.sendMessage(Component.text("Gruppe erstellen: ", NamedTextColor.YELLOW)
                            .append(Component.text("[Oeffentlich]", NamedTextColor.AQUA).clickEvent(ClickEvent.suggestCommand("/group create public ")))
                            .append(Component.text("  "))
                            .append(Component.text("[Passwortgeschuetzt]", NamedTextColor.GOLD).clickEvent(ClickEvent.suggestCommand("/group create private "))));
                    p.sendMessage(Component.text("Dann Name (und bei privat das Passwort) anhaengen, z.B. /group create private Team1 geheim", NamedTextColor.GRAY));
                    return;
                }
                boolean priv = a[1].equalsIgnoreCase("private");
                if (!priv && !a[1].equalsIgnoreCase("public")) { p.sendMessage(Component.text("Waehle public oder private.", NamedTextColor.RED)); return; }
                if (a.length < (priv ? 4 : 3)) { p.sendMessage(Component.text(priv ? "Nutzung: /group create private <Name> <Passwort>" : "Nutzung: /group create public <Name>", NamedTextColor.RED)); return; }
                groups.leave(p.getUniqueId());
                String err = groups.create(p.getUniqueId(), a[2], priv ? a[3] : null);
                if (err != null) { p.sendMessage(Component.text(err, NamedTextColor.RED)); return; }
                s.group = a[2];
                p.sendMessage(Component.text("Gruppe '" + a[2] + "' erstellt.", NamedTextColor.GREEN));
            }
            case "leave" -> {
                String g = groups.leave(p.getUniqueId());
                s.group = null;
                p.sendMessage(Component.text(g == null ? "Du bist in keiner Gruppe." : "Gruppe '" + g + "' verlassen.", NamedTextColor.GREEN));
            }
            case "join" -> {
                if (a.length == 1) {
                    List<Groups.Group> all = groups.all();
                    if (all.isEmpty()) { p.sendMessage(Component.text("Keine Gruppen vorhanden. /group create", NamedTextColor.YELLOW)); return; }
                    p.sendMessage(Component.text("Verfuegbare Gruppen (anklicken):", NamedTextColor.YELLOW));
                    for (Groups.Group g : all) {
                        Component c = Component.text(" - " + g.name + " (" + g.members.size() + ")" + (g.isPrivate() ? " [Passwort]" : ""),
                                g.isPrivate() ? NamedTextColor.GOLD : NamedTextColor.AQUA);
                        c = g.isPrivate() ? c.clickEvent(ClickEvent.suggestCommand("/group join " + g.name + " "))
                                : c.clickEvent(ClickEvent.runCommand("/group join " + g.name));
                        p.sendMessage(c);
                    }
                    return;
                }
                groups.leave(p.getUniqueId());
                s.group = null;
                String err = groups.join(p.getUniqueId(), a[1], a.length > 2 ? a[2] : null);
                if (err != null) {
                    p.sendMessage(Component.text(err, NamedTextColor.RED));
                    Groups.Group g = groups.find(a[1]);
                    if (g != null && g.isPrivate() && a.length < 3)
                        p.sendMessage(Component.text("Passwort eingeben: /group join " + g.name + " <Passwort>", NamedTextColor.YELLOW));
                    return;
                }
                s.group = groups.find(a[1]).name;
                p.sendMessage(Component.text("Gruppe '" + s.group + "' beigetreten.", NamedTextColor.GREEN));
            }
            default -> p.sendMessage(Component.text("Nutzung: /group <create|join|leave>", NamedTextColor.YELLOW));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        String n = c.getName().toLowerCase(Locale.ROOT);
        if (a.length == 1 && n.equals("vc")) return List.of("on", "off", "link");
        if (a.length == 1 && n.equals("group")) return List.of("create", "join", "leave");
        if (a.length == 2 && n.equals("group") && a[0].equalsIgnoreCase("create")) return List.of("public", "private");
        return List.of();
    }

    // ---------------------------------------------------------------- GUIs

    private ItemStack item(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(Component.text(s, NamedTextColor.GRAY));
        meta.lore(l);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack head(Player target, List<String> lore) {
        ItemStack it = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) it.getItemMeta();
        meta.setOwningPlayer(target);
        meta.displayName(Component.text(target.getName()));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(Component.text(s, NamedTextColor.GRAY));
        meta.lore(l);
        it.setItemMeta(meta);
        return it;
    }

    private void openVolume(Player p) {
        Session me = voice.byPlayer.get(p.getUniqueId());
        List<UUID> ids = new ArrayList<>();
        Gui g = new Gui("volume", null, ids);
        for (Player o : Bukkit.getOnlinePlayers()) if (!o.equals(p) && ids.size() < 45) ids.add(o.getUniqueId());
        Inventory inv = Bukkit.createInventory(g, 54, Component.text("Lautstaerke"));
        g.inv = inv;
        for (int i = 0; i < ids.size(); i++) {
            Player o = Bukkit.getPlayer(ids.get(i));
            if (o == null) continue;
            int pct = Math.round(me.volumes.getOrDefault(o.getUniqueId(), 1f) * 100);
            inv.setItem(i, head(o, List.of("Lautstaerke: " + pct + "%", "Linksklick: +10%", "Rechtsklick: -10%", "Shift-Klick: 100%")));
        }
        p.openInventory(inv);
    }

    private void openPlayers(Player admin) {
        List<UUID> ids = new ArrayList<>();
        Gui g = new Gui("sb-players", null, ids);
        for (Player o : Bukkit.getOnlinePlayers()) if (ids.size() < 54) ids.add(o.getUniqueId());
        Inventory inv = Bukkit.createInventory(g, 54, Component.text("Soundboard: Spieler waehlen"));
        g.inv = inv;
        for (int i = 0; i < ids.size(); i++) {
            Player o = Bukkit.getPlayer(ids.get(i));
            if (o == null) continue;
            Session s = voice.byPlayer.get(o.getUniqueId());
            inv.setItem(i, head(o, List.of(s != null && s.connected() ? "Mod verbunden" : "Mod NICHT verbunden - Sound nicht moeglich")));
        }
        admin.openInventory(inv);
    }

    private void openSounds(Player admin, UUID target) {
        List<String> keys = new ArrayList<>();
        Gui g = new Gui("sb-sounds", target, keys);
        Inventory inv = Bukkit.createInventory(g, 54, Component.text("Soundboard"));
        g.inv = inv;
        for (String n : sounds.builtinNames()) if (keys.size() < 45) keys.add("b:" + n);
        for (String n : sounds.customNames()) if (keys.size() < 45) keys.add("c:" + n);
        for (int i = 0; i < keys.size(); i++) {
            boolean custom = keys.get(i).startsWith("c:");
            inv.setItem(i, item(custom ? Material.JUKEBOX : Material.NOTE_BLOCK, keys.get(i).substring(2),
                    custom ? List.of("Linksklick: abspielen", "Shift+Rechtsklick: loeschen") : List.of("Linksklick: abspielen")));
        }
        inv.setItem(45, item(Material.WRITABLE_BOOK, "Upload (.ogg)", List.of("Oeffnet einen Dateidialog im Client", "Max. 2 MB / 15 Sekunden")));
        inv.setItem(49, item(Material.ARROW, "Zurueck", List.of()));
        admin.openInventory(inv);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) { if (e.getInventory().getHolder() instanceof Gui) e.setCancelled(true); }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Gui g) || !(e.getWhoClicked() instanceof Player p)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != e.getInventory()) return;
        int slot = e.getRawSlot();
        ClickType ct = e.getClick();
        Session me = voice.byPlayer.get(p.getUniqueId());
        if (me == null) return;
        switch (g.type) {
            case "volume" -> {
                if (slot < 0 || slot >= g.items.size()) return;
                UUID t = (UUID) g.items.get(slot);
                float v = me.volumes.getOrDefault(t, 1f);
                if (ct.isShiftClick()) v = 1f;
                else if (ct.isLeftClick()) v = Math.min(2f, v + 0.1f);
                else if (ct.isRightClick()) v = Math.max(0f, v - 0.1f);
                v = Math.round(v * 10f) / 10f;
                me.volumes.put(t, v);
                voice.sendCtrl(me, new Msg(Msg.S_SET_VOLUME).uuid(t).f(v).done());
                openVolume(p);
            }
            case "sb-players" -> {
                if (!p.hasPermission("primevoice.soundboard") || slot < 0 || slot >= g.items.size()) return;
                openSounds(p, (UUID) g.items.get(slot));
            }
            case "sb-sounds" -> {
                if (!p.hasPermission("primevoice.soundboard")) return;
                if (slot == 49) { openPlayers(p); return; }
                if (slot == 45) {
                    me.uploadRequestedAt = System.currentTimeMillis();
                    voice.sendCtrl(me, new Msg(Msg.S_PICK_FILE).done());
                    p.sendMessage(Component.text("Waehle im Dateidialog deines Spiels eine .ogg-Datei.", NamedTextColor.YELLOW));
                    return;
                }
                if (slot < 0 || slot >= g.items.size()) return;
                String key = (String) g.items.get(slot);
                if (ct == ClickType.SHIFT_RIGHT && key.startsWith("c:")) {
                    try { sounds.deleteCustom(key.substring(2)); } catch (Exception ex) { p.sendMessage(Component.text("Loeschen fehlgeschlagen.", NamedTextColor.RED)); }
                    openSounds(p, g.target);
                } else if (ct.isLeftClick()) {
                    play(p, g.target, key);
                }
            }
            default -> {}
        }
    }

    private void play(Player admin, UUID target, String key) {
        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("soundboard.cooldown-ms", 3000);
        Long last = sbCooldown.get(admin.getUniqueId());
        if (last != null && now - last < cd) {
            admin.sendMessage(Component.text("Cooldown: noch " + ((cd - (now - last)) / 100 / 10.0) + " s.", NamedTextColor.RED));
            return;
        }
        Player tp = Bukkit.getPlayer(target);
        Session ts = voice.byPlayer.get(target);
        if (tp == null || ts == null || !ts.connected()) { admin.sendMessage(Component.text("Spieler offline oder ohne verbundene Mod.", NamedTextColor.RED)); return; }
        float gain = (float) Math.max(0.0, Math.min(1.0, getConfig().getDouble("soundboard.max-volume", 0.6)));
        String name = key.substring(2);
        try {
            if (key.startsWith("b:")) {
                byte[] d = sounds.builtin(name);
                if (d == null) return;
                voice.sendFile(ts, Msg.KIND_PCM, gain, name, d);
            } else {
                byte[] d = sounds.custom(name);
                if (d == null) return;
                voice.sendFile(ts, Msg.KIND_OGG, gain, name, d);
            }
            sbCooldown.put(admin.getUniqueId(), now);
            admin.sendMessage(Component.text("'" + name + "' wird bei " + tp.getName() + " abgespielt (nur lokal).", NamedTextColor.GREEN));
        } catch (Exception ex) {
            admin.sendMessage(Component.text("Fehler beim Laden des Sounds.", NamedTextColor.RED));
        }
    }

    /** Fertiger Upload vom Client (UDP-Thread) -> Pruefung auf dem Hauptthread. */
    private void handleUpload(Session s, Transfer.Receiver r) {
        byte[] data = r.data();
        String raw = r.name;
        Bukkit.getScheduler().runTask(this, () -> {
            Player p = Bukkit.getPlayer(s.uuid);
            if (p == null) return;
            String err = null;
            String name = Sounds.safeName(raw);
            if (!p.hasPermission("primevoice.soundboard") || System.currentTimeMillis() - s.uploadRequestedAt > 180_000) err = "Upload nicht angefordert oder keine Berechtigung.";
            else if (data.length > getConfig().getLong("soundboard.max-bytes", 2097152)) err = "Datei groesser als 2 MB.";
            else if (name.isEmpty()) err = "Ungueltiger Dateiname.";
            else if (sounds.exists(name)) err = "Ein Sound mit diesem Namen existiert bereits.";
            else {
                double secs = Sounds.oggSeconds(data);
                if (secs < 0) err = "Keine gueltige OGG/Vorbis-Datei.";
                else if (secs > getConfig().getDouble("soundboard.max-seconds", 15)) err = "Sound laenger als 15 Sekunden (" + Math.round(secs) + " s).";
            }
            if (err == null) {
                try { sounds.saveCustom(name, data); } catch (Exception ex) { err = "Speichern fehlgeschlagen."; }
            }
            s.uploadRequestedAt = 0;
            p.sendMessage(err == null ? Component.text("Sound '" + name + "' gespeichert.", NamedTextColor.GREEN) : Component.text("Upload abgelehnt: " + err, NamedTextColor.RED));
        });
    }
}
