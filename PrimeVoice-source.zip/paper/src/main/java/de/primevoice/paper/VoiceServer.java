package de.primevoice.paper;

import de.primevoice.common.Msg;
import de.primevoice.common.Transfer;
import de.primevoice.common.Wire;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.logging.Logger;

/** UDP-Relay. Verschluesselt (AES-GCM), Replay-Schutz ueber Zaehler, kein Audio wird gespeichert. */
final class VoiceServer {
    final Map<Long, Session> bySession = new ConcurrentHashMap<>();
    final Map<UUID, Session> byPlayer = new ConcurrentHashMap<>();
    private final DatagramSocket socket;
    private final Logger log;
    private volatile boolean running = true;
    /** Wird fuer fertig empfangene Uploads aufgerufen (Session, Empfaenger). */
    BiConsumer<Session, Transfer.Receiver> onUpload = (s, r) -> {};

    VoiceServer(InetSocketAddress bind, Logger log) throws Exception {
        this.log = log;
        this.socket = new DatagramSocket(bind);
        Thread t = new Thread(this::loop, "PrimeVoice-UDP");
        t.setDaemon(true);
        t.start();
        Thread r = new Thread(this::retransmitLoop, "PrimeVoice-Retransmit");
        r.setDaemon(true);
        r.start();
    }

    void close() { running = false; socket.close(); }

    private void loop() {
        byte[] buf = new byte[1500];
        while (running) {
            try {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                socket.receive(p);
                handle(p);
            } catch (Exception e) {
                if (running && !socket.isClosed()) log.fine("UDP: " + e.getMessage());
            }
        }
    }

    private void handle(DatagramPacket p) throws Exception {
        int len = p.getLength();
        byte[] d = p.getData();
        if (!Wire.plausible(len)) return;
        Session s = bySession.get(Wire.session(d));
        if (s == null) return;
        long ctr = Wire.counter(d);
        if (ctr <= s.lastCounter) return; // Replay / alt
        byte[] plain;
        try { plain = Wire.open(d, len, Wire.DIR_C2S, s.key); } catch (Exception e) { return; } // manipuliert
        s.lastCounter = ctr;
        s.addr = new InetSocketAddress(p.getAddress(), p.getPort());
        s.lastSeen = System.currentTimeMillis();
        switch (Wire.type(d)) {
            case Wire.T_HELLO -> sendCtrl(s, new Msg(Msg.S_MIC).b(s.micOn ? 1 : 0).done());
            case Wire.T_AUDIO_UP -> audio(s, plain);
            case Wire.T_CTRL -> ctrl(s, plain);
            default -> {}
        }
    }

    private void audio(Session s, byte[] plain) throws Exception {
        if (!s.micOn || plain.length < 3 || plain.length > 600) return;
        s.lastTalk = System.currentTimeMillis();
        Map<UUID, float[]> aud = s.audible;
        s.listenerCount = aud.size();
        for (Map.Entry<UUID, float[]> e : aud.entrySet()) {
            Session r = byPlayer.get(e.getKey());
            if (r == null || r.addr == null) continue;
            float[] v = e.getValue();
            ByteBuffer b = ByteBuffer.allocate(16 + 3 + plain.length);
            b.putLong(s.uuid.getMostSignificantBits()).putLong(s.uuid.getLeastSignificantBits());
            b.put((byte) Math.round(Math.max(0, Math.min(1, v[0])) * 255));
            b.put((byte) Math.round(Math.max(-1, Math.min(1, v[1])) * 127));
            b.put((byte) Math.round(v[2]));
            b.put(plain); // seq(2) + opus
            send(r, Wire.T_AUDIO_DOWN, b.array());
        }
    }

    private void ctrl(Session s, byte[] plain) {
        Msg.In in = new Msg.In(plain);
        int type = in.b();
        switch (type) {
            case Msg.C_STATE -> s.clientHasMic = in.b() == 1;
            case Msg.C_VOLUMES -> {
                int n = Math.min(in.s(), 200);
                for (int i = 0; i < n && in.remaining() >= 20; i++) s.volumes.put(in.uuid(), in.f());
            }
            case Msg.FILE_BEGIN -> {
                int id = in.i(), kind = in.b(), total = in.i();
                float gain = in.f();
                String name = in.str();
                if (kind != Msg.KIND_UPLOAD || total <= 0 || total > 2_200_000 || s.incoming.size() > 2) return;
                s.incoming.putIfAbsent(id, new Transfer.Receiver(id, kind, gain, name, total));
                sendCtr(s, new Msg(Msg.FILE_ACK).i(id).i(-1).done());
            }
            case Msg.FILE_CHUNK -> {
                int id = in.i(), idx = in.i(), len = in.s();
                Transfer.Receiver r = s.incoming.get(id);
                if (r == null || len > Transfer.CHUNK || in.remaining() < len) return;
                r.put(idx, in.bytes(len));
                sendCtr(s, new Msg(Msg.FILE_ACK).i(id).i(idx).done());
                if (r.done() && s.incoming.remove(id, r)) onUpload.accept(s, r);
            }
            case Msg.FILE_ACK -> {
                int id = in.i(), idx = in.i();
                Transfer.Sender snd = s.outgoing.get(id);
                if (snd == null) return;
                snd.ack(idx);
                if (snd.done()) s.outgoing.remove(id);
            }
            default -> {}
        }
    }

    private void sendCtr(Session s, byte[] m) { sendCtrl(s, m); }

    void sendCtrl(Session s, byte[] msg) { send(s, Wire.T_CTRL, msg); }

    private void send(Session s, int type, byte[] plain) {
        InetSocketAddress a = s.addr;
        if (a == null) return;
        try {
            byte[] pkt = Wire.seal(type, s.id, s.sendCtr.getAndIncrement(), Wire.DIR_S2C, s.key, plain);
            socket.send(new DatagramPacket(pkt, pkt.length, a));
        } catch (Exception e) { log.fine("send: " + e.getMessage()); }
    }

    /** Startet die Uebertragung einer Datei zum Client (zuverlaessig, Fenster + Wiederholung). */
    void sendFile(Session s, int kind, float gain, String name, byte[] data) {
        int id = (int) (System.nanoTime() & 0x7fffffff);
        Transfer.Sender snd = new Transfer.Sender(id, data);
        s.outgoing.put(id, snd);
        sendCtrl(s, new Msg(Msg.FILE_BEGIN).i(id).b(kind).i(data.length).f(gain).str(name).done());
    }

    private void retransmitLoop() {
        while (running) {
            try {
                Thread.sleep(100);
                long now = System.currentTimeMillis();
                for (Session s : bySession.values()) {
                    for (Transfer.Sender snd : s.outgoing.values()) {
                        if (now - s.lastSeen > 15000) { s.outgoing.remove(snd.id); continue; }
                        for (int idx : snd.due(now)) sendCtrl(s, snd.chunk(idx));
                    }
                }
            } catch (InterruptedException e) { return; } catch (Exception ignored) {}
        }
    }
}
