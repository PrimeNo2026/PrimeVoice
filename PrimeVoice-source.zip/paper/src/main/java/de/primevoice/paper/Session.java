package de.primevoice.paper;

import de.primevoice.common.Transfer;
import java.net.InetSocketAddress;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

final class Session {
    final UUID uuid;
    final String name;
    final long id;
    final byte[] key;
    volatile InetSocketAddress addr;       // erst nach erstem authentifiziertem Paket gesetzt
    volatile long lastCounter = 0;
    final AtomicLong sendCtr = new AtomicLong(1);
    volatile long lastSeen = 0;
    volatile boolean micOn = true;         // /vc on|off
    volatile boolean clientHasMic = false; // vom Client gemeldet
    volatile String group;
    volatile long lastTalk = 0;
    volatile int listenerCount = 0;
    final Map<UUID, Float> volumes = new ConcurrentHashMap<>();
    volatile Map<UUID, float[]> audible = Map.of(); // Hoerer -> {gain, pan, muffle}
    final Map<Integer, Transfer.Receiver> incoming = new ConcurrentHashMap<>();
    final Map<Integer, Transfer.Sender> outgoing = new ConcurrentHashMap<>();
    volatile long uploadRequestedAt = 0;

    Session(UUID uuid, String name, long id, byte[] key) {
        this.uuid = uuid; this.name = name; this.id = id; this.key = key;
    }
    boolean connected() { return addr != null && System.currentTimeMillis() - lastSeen < 15000; }
}
