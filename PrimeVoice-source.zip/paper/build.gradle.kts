plugins {
    java
}

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:26.3.build.+")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}

sourceSets.main {
    java.srcDir("../common/java")
}

tasks.jar {
    archiveFileName.set("PrimeVoice-Paper-26.3.jar")
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
}
