package de.primevoice.client;

import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/**
 * Forge-Glue: faengt die Link-Nachricht des Servers ab. Der Rest ist reines Java (client-core).
 * HINWEIS: Nutzt die Forge-Event-API und muss ggf. an die MDK-Beispiele fuer 26.3 angepasst werden.
 */
@Mod("primevoice")
public final class PrimeVoiceMod {
    public PrimeVoiceMod(FMLJavaModLoadingContext context) {
        ClientChatReceivedEvent.BUS.addListener(PrimeVoiceMod::onChat);
    }

    private static boolean onChat(ClientChatReceivedEvent e) {
        return LinkHandler.accept(e.getMessage().getString()); // true = Nachricht verwerfen
    }
}
