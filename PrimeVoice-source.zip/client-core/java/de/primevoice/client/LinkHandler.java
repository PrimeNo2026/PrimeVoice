package de.primevoice.client;

import de.primevoice.common.Wire;
import java.nio.file.Path;

/** Gemeinsame Logik fuer Forge und Fabric: wertet die unsichtbare Link-Nachricht des Servers aus. */
public final class LinkHandler {
    private static VoiceClient client;
    private static Volumes volumes;

    private LinkHandler() {}

    /** @return true, wenn die Nachricht eine PrimeVoice-Link-Nachricht war (und nicht angezeigt werden soll). */
    public static synchronized boolean accept(String message) {
        if (message == null || !message.startsWith(Wire.LINK_PREFIX)) return false;
        try {
            String[] p = message.substring(Wire.LINK_PREFIX.length()).split("\\|");
            if (volumes == null) volumes = new Volumes(Path.of("config"));
            if (client != null) client.stop();
            client = new VoiceClient(p[0], Integer.parseInt(p[1]), Long.parseUnsignedLong(p[2], 16), Wire.unhex(p[3]), volumes);
        } catch (Exception ignored) {}
        return true;
    }
}
