package de.primevoice.client;

import de.primevoice.common.Msg;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;

/** Spielt Soundboard-Sounds ausschliesslich lokal ab (nie ueber den Voicechat). */
final class SoundPlayer {
    private static final float CAP = 0.8f;          // harte Lautstaerkegrenze
    private static final int MAX_SECONDS = 15;

    private SoundPlayer() {}

    static void play(int kind, byte[] data, float gain, float master) {
        Thread t = new Thread(() -> {
            try {
                short[] pcm; int rate, channels;
                if (kind == Msg.KIND_PCM) {
                    ByteBuffer b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
                    pcm = new short[data.length / 2];
                    for (int i = 0; i < pcm.length; i++) pcm[i] = b.getShort();
                    rate = 22050; channels = 1;
                } else if (kind == Msg.KIND_OGG) {
                    OggDecoder.Result r = OggDecoder.decode(data);
                    if (r == null) return;
                    pcm = r.pcm(); rate = r.rate(); channels = r.channels();
                } else return;
                int max = rate * channels * MAX_SECONDS;
                int n = Math.min(pcm.length, max);
                float g = Math.max(0f, Math.min(CAP, gain)) * Math.max(0f, Math.min(1f, master));
                byte[] out = new byte[n * 2];
                ByteBuffer ob = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN);
                for (int i = 0; i < n; i++) ob.putShort((short) Math.max(-32768, Math.min(32767, Math.round(pcm[i] * g))));
                AudioFormat f = new AudioFormat(rate, 16, channels, true, false);
                try (SourceDataLine line = AudioSystem.getSourceDataLine(f)) {
                    line.open(f);
                    line.start();
                    line.write(out, 0, out.length);
                    line.drain();
                }
            } catch (Throwable ignored) { /* kein Audiogeraet: still ignorieren */ }
        }, "PrimeVoice-Sound");
        t.setDaemon(true);
        t.start();
    }
}
