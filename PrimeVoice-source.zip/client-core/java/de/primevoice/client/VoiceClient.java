package de.primevoice.client;

import de.primevoice.common.Msg;
import de.primevoice.common.Transfer;
import de.primevoice.common.Wire;
import java.awt.FileDialog;
import java.io.File;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;
import org.concentus.OpusApplication;
import org.concentus.OpusDecoder;
import org.concentus.OpusEncoder;

/** Mikrofon -> Opus -> AES-GCM -> UDP; UDP -> Opus -> Mischer (Stereo, Pan, Daempfung, lokale Lautstaerke). */
public final class VoiceClient {
    private static final float MIC_THRESHOLD_DB = -50f;

    private final InetSocketAddress server;
    private final long sid;
    private final byte[] key;
    private final Volumes volumes;
    private final DatagramSocket socket;
    private final AtomicLong ctr = new AtomicLong(1);
    private volatile long lastIn = 0, lastValid = 0;
    private volatile boolean running = true, micEnabled = true, greeted = false, micPresent = false;
    private final Map<Integer, Transfer.Receiver> incoming = new ConcurrentHashMap<>();
    private final Map<Integer, Transfer.Sender> outgoing = new ConcurrentHashMap<>();
    private final Map<UUID, Stream> streams = new ConcurrentHashMap<>();
    private volatile boolean uploadStarted = false, uploadAcked = false;
    private volatile byte[] uploadBegin;

    private static final class Frame { short[] pcm; float gain, pan; int muffle; }
    private static final class Stream {
        final OpusDecoder dec;
        final ArrayDeque<Frame> q = new ArrayDeque<>();
        boolean primed = false;
        float lp = 0;
        volatile long last = 0;
        Stream() throws Exception { dec = new OpusDecoder(Wire.RATE, 1); }
    }

    public VoiceClient(String host, int port, long sid, byte[] key, Volumes volumes) throws Exception {
        this.server = new InetSocketAddress(host, port);
        this.sid = sid; this.key = key; this.volumes = volumes;
        this.socket = new DatagramSocket();
        this.socket.setSoTimeout(1000);
        daemon(this::recvLoop, "PV-Recv");
        daemon(this::keepAliveLoop, "PV-Keepalive");
        daemon(this::micLoop, "PV-Mic");
        daemon(this::playLoop, "PV-Play");
    }

    public void stop() { running = false; socket.close(); }
    public boolean isRunning() { return running; }

    private static void daemon(Runnable r, String n) { Thread t = new Thread(r, n); t.setDaemon(true); t.start(); }

    private void send(int type, byte[] plain) {
        try {
            byte[] p = Wire.seal(type, sid, ctr.getAndIncrement(), Wire.DIR_C2S, key, plain);
            socket.send(new DatagramPacket(p, p.length, server));
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------------ Empfang

    private void recvLoop() {
        byte[] buf = new byte[1500];
        while (running) {
            try {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                socket.receive(p);
                int len = p.getLength();
                if (!Wire.plausible(len) || Wire.session(buf) != sid) continue;
                long c = Wire.counter(buf);
                if (c <= lastIn) continue;
                byte[] plain;
                try { plain = Wire.open(buf, len, Wire.DIR_S2C, key); } catch (Exception e) { continue; }
                lastIn = c;
                lastValid = System.currentTimeMillis();
                if (!greeted) { greeted = true; sendState(); sendVolumes(); }
                switch (Wire.type(buf)) {
                    case Wire.T_AUDIO_DOWN -> onAudio(plain);
                    case Wire.T_CTRL -> onCtrl(plain);
                    default -> {}
                }
            } catch (java.net.SocketTimeoutException ignored) {
            } catch (Exception e) { if (!running) return; }
        }
    }

    private void onAudio(byte[] d) {
        try {
            if (d.length < 16 + 3 + 2 + 1) return;
            ByteBuffer b = ByteBuffer.wrap(d);
            UUID who = new UUID(b.getLong(), b.getLong());
            Frame f = new Frame();
            f.gain = (b.get() & 0xFF) / 255f;
            f.pan = b.get() / 127f;
            f.muffle = b.get() & 0xFF;
            b.getShort(); // seq
            byte[] opus = new byte[b.remaining()];
            b.get(opus);
            Stream s = streams.get(who);
            if (s == null) { s = new Stream(); streams.put(who, s); }
            synchronized (s) {
                f.pcm = new short[Wire.FRAME];
                s.dec.decode(opus, 0, opus.length, f.pcm, 0, Wire.FRAME, false);
                s.q.addLast(f);
                while (s.q.size() > 8) s.q.pollFirst();
                s.last = System.currentTimeMillis();
            }
        } catch (Exception ignored) {}
    }

    private void onCtrl(byte[] d) {
        try {
            Msg.In in = new Msg.In(d);
            switch (in.b()) {
                case Msg.S_SET_VOLUME -> volumes.set(in.uuid(), in.f());
                case Msg.S_MIC -> micEnabled = in.b() == 1;
                case Msg.S_PICK_FILE -> pickFile();
                case Msg.FILE_BEGIN -> {
                    int id = in.i(), kind = in.b(), total = in.i();
                    float gain = in.f();
                    String name = in.str();
                    if ((kind == Msg.KIND_OGG || kind == Msg.KIND_PCM) && total > 0 && total <= 2_300_000 && incoming.size() < 3)
                        incoming.putIfAbsent(id, new Transfer.Receiver(id, kind, gain, name, total));
                }
                case Msg.FILE_CHUNK -> {
                    int id = in.i(), idx = in.i(), len = in.s();
                    Transfer.Receiver r = incoming.get(id);
                    if (r == null || len > Transfer.CHUNK || in.remaining() < len) return;
                    r.put(idx, in.bytes(len));
                    send(Wire.T_CTRL, new Msg(Msg.FILE_ACK).i(id).i(idx).done());
                    if (r.done() && incoming.remove(id, r)) SoundPlayer.play(r.kind, r.data(), r.gain, volumes.master());
                }
                case Msg.FILE_ACK -> {
                    int id = in.i(), idx = in.i();
                    Transfer.Sender s = outgoing.get(id);
                    if (s == null) return;
                    if (idx >= 0) { uploadAcked = true; s.ack(idx); }
                    if (s.done()) outgoing.remove(id);
                }
                default -> {}
            }
        } catch (Exception ignored) {}
    }

    private void sendState() { send(Wire.T_CTRL, new Msg(Msg.C_STATE).b(micPresent ? 1 : 0).done()); }

    private void sendVolumes() {
        Map<UUID, Float> all = volumes.all();
        Msg m = new Msg(Msg.C_VOLUMES).s(Math.min(all.size(), 200));
        int n = 0;
        for (Map.Entry<UUID, Float> e : all.entrySet()) { if (n++ >= 200) break; m.uuid(e.getKey()).f(e.getValue()); }
        send(Wire.T_CTRL, m.done());
    }

    private void keepAliveLoop() {
        long lastBegin = 0;
        while (running) {
            try {
                Thread.sleep(100);
                long now = System.currentTimeMillis();
                if (now % 5000 < 100 || (!greeted && now % 1000 < 100)) send(Wire.T_HELLO, new byte[] {'P', 'V'});
                if (greeted && now - lastValid > 60_000) { stop(); return; }
                for (Transfer.Sender s : outgoing.values()) {
                    if (!uploadAcked && uploadBegin != null && now - lastBegin > 1000) { send(Wire.T_CTRL, uploadBegin); lastBegin = now; }
                    for (int idx : s.due(now)) send(Wire.T_CTRL, s.chunk(idx));
                }
                streams.entrySet().removeIf(e -> now - e.getValue().last > 3000);
            } catch (InterruptedException e) { return; } catch (Exception ignored) {}
        }
    }

    // ------------------------------------------------------------------ Upload (Dateidialog)

    private void pickFile() {
        daemon(() -> {
            try {
                FileDialog fd = new FileDialog((java.awt.Frame) null, "PrimeVoice: OGG-Datei waehlen", FileDialog.LOAD);
                fd.setFilenameFilter((dir, n) -> n.toLowerCase().endsWith(".ogg"));
                fd.setVisible(true);
                if (fd.getFile() == null) return;
                File f = new File(fd.getDirectory(), fd.getFile());
                if (!f.isFile() || f.length() > 2 * 1024 * 1024) return;
                byte[] data = Files.readAllBytes(f.toPath());
                int id = (int) (System.nanoTime() & 0x7fffffff);
                uploadAcked = false;
                uploadBegin = new Msg(Msg.FILE_BEGIN).i(id).b(Msg.KIND_UPLOAD).i(data.length).f(0f).str(f.getName()).done();
                outgoing.put(id, new Transfer.Sender(id, data));
                send(Wire.T_CTRL, uploadBegin);
            } catch (Throwable ignored) {}
        }, "PV-Pick");
    }

    // ------------------------------------------------------------------ Mikrofon

    private void micLoop() {
        AudioFormat f = new AudioFormat(Wire.RATE, 16, 1, true, false);
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, f);
        TargetDataLine line = null;
        OpusEncoder enc = null;
        byte[] buf = new byte[Wire.FRAME * 2];
        short[] pcm = new short[Wire.FRAME];
        byte[] out = new byte[400];
        int hold = 0, seq = 0;
        while (running) {
            try {
                if (!micEnabled) { if (line != null) { line.close(); line = null; } setMic(false); Thread.sleep(300); continue; }
                if (line == null) {
                    if (!AudioSystem.isLineSupported(info)) { setMic(false); Thread.sleep(3000); continue; } // kein Mikrofon: still warten
                    line = (TargetDataLine) AudioSystem.getLine(info);
                    line.open(f, buf.length * 6);
                    line.start();
                    if (enc == null) { enc = new OpusEncoder(Wire.RATE, 1, OpusApplication.OPUS_APPLICATION_VOIP); enc.setBitrate(24000); enc.setComplexity(5); }
                    setMic(true);
                }
                int got = 0;
                while (got < buf.length) { int n = line.read(buf, got, buf.length - got); if (n <= 0) throw new IllegalStateException(); got += n; }
                double sum = 0;
                for (int i = 0; i < Wire.FRAME; i++) {
                    pcm[i] = (short) ((buf[2 * i] & 0xFF) | (buf[2 * i + 1] << 8));
                    sum += (double) pcm[i] * pcm[i];
                }
                double db = 20 * Math.log10(Math.max(1e-9, Math.sqrt(sum / Wire.FRAME) / 32768.0));
                if (db > MIC_THRESHOLD_DB) hold = 15; else if (hold > 0) hold--;
                if (hold == 0 || !greeted) continue;
                int len = enc.encode(pcm, 0, Wire.FRAME, out, 0, out.length);
                ByteBuffer b = ByteBuffer.allocate(2 + len);
                b.putShort((short) (seq++ & 0xFFFF)).put(out, 0, len);
                send(Wire.T_AUDIO_UP, b.array());
            } catch (Throwable t) {
                // Mikrofon verschwunden o.ae.: ohne Fehlermeldung schliessen und spaeter neu erkennen
                try { if (line != null) line.close(); } catch (Throwable ignored) {}
                line = null;
                setMic(false);
                try { Thread.sleep(3000); } catch (InterruptedException e) { return; }
            }
        }
        try { if (line != null) line.close(); } catch (Throwable ignored) {}
    }

    private void setMic(boolean present) {
        if (micPresent != present) { micPresent = present; if (greeted) sendState(); }
    }

    // ------------------------------------------------------------------ Wiedergabe / Mischer

    private static final float[] LP = {1f, 0.35f, 0.18f, 0.10f};

    private void playLoop() {
        AudioFormat f = new AudioFormat(Wire.RATE, 16, 2, true, false);
        byte[] out = new byte[Wire.FRAME * 4];
        float[] mix = new float[Wire.FRAME * 2];
        SourceDataLine line = null;
        while (running) {
            try {
                if (line == null) {
                    line = AudioSystem.getSourceDataLine(f);
                    line.open(f, out.length * 4);
                    line.start();
                }
                java.util.Arrays.fill(mix, 0f);
                float master = volumes.master();
                for (Map.Entry<UUID, Stream> e : streams.entrySet()) {
                    Stream s = e.getValue();
                    Frame fr = null;
                    synchronized (s) {
                        if (!s.primed && s.q.size() >= 2) s.primed = true;
                        if (s.primed) { fr = s.q.pollFirst(); if (fr == null) s.primed = false; }
                    }
                    if (fr == null) continue;
                    float vol = fr.gain * volumes.get(e.getKey()) * master;
                    float a = LP[Math.max(0, Math.min(3, fr.muffle))];
                    double ang = (fr.pan + 1) * Math.PI / 4;
                    float l = (float) Math.cos(ang), r = (float) Math.sin(ang);
                    for (int i = 0; i < Wire.FRAME; i++) {
                        float x = fr.pcm[i] / 32768f;
                        s.lp += a * (x - s.lp);
                        float y = s.lp * vol;
                        mix[2 * i] += y * l;
                        mix[2 * i + 1] += y * r;
                    }
                }
                for (int i = 0; i < mix.length; i++) {
                    int v = Math.max(-32768, Math.min(32767, Math.round(mix[i] * 32767f)));
                    out[2 * i] = (byte) v;
                    out[2 * i + 1] = (byte) (v >> 8);
                }
                line.write(out, 0, out.length);
            } catch (Throwable t) {
                try { if (line != null) line.close(); } catch (Throwable ignored) {}
                line = null;
                try { Thread.sleep(3000); } catch (InterruptedException ex) { return; }
            }
        }
        try { if (line != null) line.close(); } catch (Throwable ignored) {}
    }
}
