package de.primevoice.client;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.UUID;

/** Lokal gespeicherte Lautstaerken (config/primevoice-volumes.properties). */
public final class Volumes {
    private final Path file;
    private final Properties props = new Properties();

    public Volumes(Path configDir) {
        this.file = configDir.resolve("primevoice-volumes.properties");
        try (InputStream in = Files.newInputStream(file)) { props.load(in); } catch (Exception ignored) {}
    }

    public synchronized float get(UUID u) {
        try { return Float.parseFloat(props.getProperty(u.toString(), "1.0")); } catch (Exception e) { return 1f; }
    }
    public synchronized float master() {
        try { return Float.parseFloat(props.getProperty("master", "1.0")); } catch (Exception e) { return 1f; }
    }
    public synchronized void set(UUID u, float v) { props.setProperty(u.toString(), Float.toString(Math.max(0f, Math.min(2f, v)))); save(); }
    public synchronized java.util.Map<UUID, Float> all() {
        java.util.Map<UUID, Float> m = new java.util.HashMap<>();
        for (String k : props.stringPropertyNames()) {
            try { m.put(UUID.fromString(k), Float.parseFloat(props.getProperty(k))); } catch (Exception ignored) {}
        }
        return m;
    }
    private void save() {
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(file)) { props.store(out, "PrimeVoice"); }
        } catch (Exception ignored) {}
    }
}
