package de.primevoice.client;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryStack;

/** OGG/Vorbis-Dekodierung ueber das in Minecraft mitgelieferte LWJGL-STB. */
final class OggDecoder {
    record Result(short[] pcm, int rate, int channels) {}

    private OggDecoder() {}

    static Result decode(byte[] ogg) {
        ByteBuffer mem = ByteBuffer.allocateDirect(ogg.length).order(ByteOrder());
        mem.put(ogg).flip();
        try (MemoryStack stack = MemoryStack.stackPush()) {
            IntBuffer ch = stack.mallocInt(1);
            IntBuffer rate = stack.mallocInt(1);
            ShortBuffer pcm = STBVorbis.stb_vorbis_decode_memory(mem, ch, rate);
            if (pcm == null) return null;
            short[] out = new short[pcm.remaining()];
            pcm.get(out);
            org.lwjgl.system.libc.LibCStdlib.free(pcm);
            return new Result(out, rate.get(0), ch.get(0));
        }
    }

    private static java.nio.ByteOrder ByteOrder() { return java.nio.ByteOrder.nativeOrder(); }
}
