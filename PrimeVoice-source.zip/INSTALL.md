# Installation (ohne lokale Tools)

## 1. Repository einrichten (nur einmal)
1. Auf github.com ein neues Repository anlegen.
2. **Add file > Upload files**: `PrimeVoice-source.zip` hochladen (nicht entpacken) und committen.
3. **Add file > Create new file**: Dateiname `.github/workflows/build.yml` eingeben, Inhalt der mitgelieferten `build.yml` einfuegen, committen.
   (Der Workflow entpackt die ZIP selbst.)

## 2. Bauen / Release
* Testbuild: Reiter **Actions > Build PrimeVoice > Run workflow**. Fertige JARs: im Lauf unter *Artifacts*.
* Release: **Releases > Draft a new release**, Tag z.B. `v1.0.0`, **Publish**. Danach haengen nach einigen Minuten alle drei JARs am Release.

## 3. Server (exaroton, Paper 26.3)
* `PrimeVoice-Paper-26.3.jar` in `plugins/` hochladen, Server neu starten.
* Es wird nur der normale Server-Port genutzt (UDP gleiche Nummer). Hostest du mit einer Adresse ohne Port, setze in `plugins/PrimeVoice/config.yml` `public-host` und `public-port`.
* Admins: Permission `primevoice.soundboard`.

## 4. Spieler
* **Forge:** Forge 26.3 installieren, `PrimeVoice-Forge-26.3.jar` in `mods/` legen.
* **Fabric:** Fabric Loader (ab 0.19.5) und Fabric API fuer 26.3 installieren, `PrimeVoice-Fabric-26.3.jar` in `mods/` legen.
* Server beitreten, die Verbindung baut sich automatisch auf.
